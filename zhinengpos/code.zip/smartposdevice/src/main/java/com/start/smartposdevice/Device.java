package com.start.smartposdevice;

/**
 * 是所有设备的根类，每个设备只能同时被一个实例使用
 */
public interface Device {
	/**
	 * 打开指定ID的设备。默认设备ID为0
	 * @param LogicID 设备ID
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void open(int LogicID) throws DeviceException;

	/**
	 * 关闭指定ID的设备。
	 * @param LogicID 设备ID。
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void close(int LogicID) throws DeviceException;

	/**
	 * 取消设备操作。该方法用于尝试取消一个正在执行的异步操作或带有timeout的同步操作。
	 * <p>设备对象的每种方法对cancelRequest的响应不同，具体包括以下3种：
	 * <ul>
	 *     <li>如果设备对象的某个方法参数中带有一个listener，必须 响应 cancelRequest方法，并且放弃当前的操作。</li>
	 *     <li>如果设备对象的某个方法参数中带有一个timeout，必须 响应 cancelRequest方法，并且放弃当前的操作。</li>
	 *     <li>其他方法我们视作同步方法，可以响应或者不响应cancelRequest方法，这个 需要根据每个设备具体情况和文档确定。</li>
	 * </ul>
	 * @param LogicID 设备ID
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void cancelRequest(int LogicID) throws DeviceException;
}
