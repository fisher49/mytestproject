package com.start.smartposdevice;

/**
 * 定义了异常的形式和内容
 */
public class DeviceException extends Exception{
    private static final long serialVersionUID = 3774214074554394396L;

    private int code;

    /**
     * 设备device没有处于合适的状态。比如：
     * <ul>
     * <li>如果设备在已经open的情况下，使用者再次调用了<code>open()</code>方法。
     * <li>如果设备在没有open的情况下，使用者调用了设备任何一个设备操作方法。
     * <li>某些设备的一些方法，在不合适的情况下被调用了。具体看每个设备的方法定义。
     * </ul>
     */
    public static final int BAD_CONTROL_MODE = -1;

    /**
     * 设备不支持该功能的调用:
     *
     */
    public static final int NO_IMPLEMENT = -2;
    /**
     * <ul>
     * <li>一个异步方法还在执行中，调用了非<code>cancelRequest</code>方法，<code>open()</code>方法除外（这种情况下应该是是BAD_CONTROL_MODE）。
     * </ul>
     */
    public static final int REQUEST_PENDING = -3;

    /**
     * 当用户调用<code>cancelRequest</code>的时候，没有异步方法正在被执行。
     */
    public static final int NO_REQUEST_PENDING = -4;

    /**
     * 用户没有权限调用这个方法。
     */
    public static final int NO_PERMISSION = -5;

    /**
     * 其他未定义的错误。可以通过message获得更多信息。
     */
    public static final int GENERAL_EXCEPTION = -6;

    /**
     * 方法参数错误。
     */
    public static final int ARGUMENT_EXCEPTION = -7;

    /**
     * 异常构造器
     * @param code 异常标识
     * @param message 异常信息
     */
    public DeviceException(int code, String message) {
        super(message);
        this.code = code;
    }

    /**
     * 返回异常code
     *
     * @return 返回一个在<b>DeviceException</b>中定义的常量    
     */
    public final int getCode() {
        return code;
    }

}
