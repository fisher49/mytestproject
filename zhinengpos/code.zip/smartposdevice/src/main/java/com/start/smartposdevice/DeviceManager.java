package com.start.smartposdevice;

import android.content.Context;

import java.io.File;

import dalvik.system.DexClassLoader;

/**
 * 设备管理器是接口实现的入口，定义了一些公共的接口和方法。
 */
public abstract class DeviceManager {

	/**
	 * 打印设备
	 */
	public static final String DEVICE_NAME_PRINTER = "smartpos.device.printer";
	/**
	 * 硬加密设备
	 */
	public static final String DEVICE_NAME_HSM = "smartpos.device.hsm";
	/**
	 * 密码键盘设备
	 */
	public static final String DEVICE_NAME_PINPAD = "smartpos.device.pinpad";
	/**
	 * 串口设备
	 */
	public static final String DEVICE_NAME_SERIALPORT = "smartpos.device.serialport";
	/**
	 * 钱箱设备
	 */
	public static final String DEVICE_NAME_CASH_DRAWER = "smartpos.device.cashdrawer";
	/**
	 * EMV内核模块
	 */
	public static final String DEVICE_NAME_EMV = "smartpos.device.emv";
	/**
	 * 网络设备
	 */
	public static final String DEVICE_NAME_NETWORK = "smartpos.device.network";
	/**
	 * 磁条卡读卡器设备
	 */
	public static final String DEVICE_NAME_MAGCARDREADER = "smartpos.device.magcardreader";
	/**
	 * PSAM卡读卡器设备
	 */
	public static final String DEVICE_NAME_PSAM = "smartpos.device.psam";
	/**
	 * 非接读卡器设备
	 */
	public static final String DEVICE_NAME_RFCARDREADER = "smartpos.device.rfcardreader";
	/**
	 * 接触式IC卡读卡器
	 */
	public static final String DEVICE_NAME_SMARTCARDREADER = "smartpos.device.smartcardreader";
	/**
	 * 系统设备
	 */
	public static final String DEVICE_NAME_SYSTEM = "smartpos.device.system";
//	public static final String DEVICE_NAME_USB = "smartpos.device.usb";
//	public static final String DEVICE_NAME_WIFI = "smartpos.device.wifi";
//	public static final String DEVICE_NAME_BASIC = "smartpos.device.basic";
	/**
	 * 系统属性
	 */
	public static final String DEVICE_MANAGER_CLASS = "smartpos.devicemanager.class";
	private static DeviceManager self = null;
	private static final String LOAD_JAR_PATH = "/data/cloudpossdk/cloudpossdkimpl.jar";
	protected static Context androidContext = null;

	/**
	 * 返回设备管理器的实例对象。终端系统默认的className是：“com.start.smartposdeviceimpl.DeviceManagerImpl”
	 * <p>可以通过System.setProperty(DeviceManager.DEVICE_MANAGER_CLASS, "com.start.smartposdeviceimpl.DeviceManagerImpl")设置系统属性。</p>
	 * <p>如果未设置，将取默认名称。</p>
	 * @param context 应用上下文
	 * @return 设备管理器
	 */
	public static synchronized DeviceManager getInstance(Context context) {
		androidContext = context;
		if (self == null) {
			Object terminalObj = null;
			String className = System.getProperty(DEVICE_MANAGER_CLASS);
			if(className == null){
				className = "com.start.smartposdeviceimpl.DeviceManagerImpl";
			}
			try {
				// 从系统指定路径中加载sdk实现。
				File dexOutputDir = context.getDir("dex", Context.MODE_PRIVATE);
				DexClassLoader dexClassLoader = new DexClassLoader(LOAD_JAR_PATH, dexOutputDir.getAbsolutePath(), null, DeviceManager.class.getClassLoader());// success
				Class<?>  clazz = dexClassLoader.loadClass(className);
				// return the real implementation
				terminalObj = clazz.newInstance();
				if(terminalObj instanceof DeviceManager){
					self = (DeviceManager)terminalObj;
				}
			}
			catch (Exception e) {
				// 无法从指定目录获得sdk对象。
				e.printStackTrace();
			}
			if(self == null){
				// 从系统中加载默认的sdk实现地址。
				try {
					Class<?> clazz = Class.forName(className);
					terminalObj = clazz.newInstance();
					if(terminalObj instanceof DeviceManager){
						self = (DeviceManager)terminalObj;
					}
				}
				catch (ClassNotFoundException e) {
					e.printStackTrace();
				}
				catch (InstantiationException e) {
					e.printStackTrace();
				}
				catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			}
		}
		return self;
	}

	/**
	 * 列出所有设备名称标识。
	 *
	 * @return String[] 设备列表
	 */
	abstract public String[] listDevices();

	/**
	 * 返回设备对象。
	 * @param deviceName 设备名称标识
	 * @return Device 设备对象
	 */
	abstract public Device getDevice(String deviceName);

}
