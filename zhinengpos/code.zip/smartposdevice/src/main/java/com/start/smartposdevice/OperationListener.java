package com.start.smartposdevice;

/**
 * 异步方法的监听接口
 */
public interface OperationListener {

    /**
     * 当异步操作动作完成后，该方法被调用。
     *<p>异步操作的结果会设置到<code>OperationResult</code>中，应用程序根据回调函数中传递过来的<code>OperationResult</code>，判断结果数据。
     * @param result 异步操作动作的结果
     * @see OperationResult
     */
    void handleResult(OperationResult result);
    
}
