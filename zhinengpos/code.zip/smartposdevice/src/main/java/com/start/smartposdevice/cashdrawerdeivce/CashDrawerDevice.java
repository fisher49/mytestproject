package com.start.smartposdevice.cashdrawerdeivce;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;

/**
 * 钱箱设备接口
 */
public interface CashDrawerDevice extends Device{

	/**
	 * 弹出钱箱
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void kickout() throws DeviceException;
}
