package com.start.smartposdevice.emvdevice;

/**
 * IC卡日志
 */

public class EMVCardLog {

	/**
	 * 交易金额存在标识
	 */
	private boolean isAmtExist;
	/**
	 * 交易金额（右靠左补0）
	 */
	private String amt;
	/**
	 * 其它金额存在标识
	 */
	private boolean isOtherAmtExist;
	/**
	 * 其它金额（右靠左补0）
	 */
	private String otherAmt;
	/**
	 * 存在交易日期（YYMMDD）
	 */
	private boolean isDateExist;
	/**
	 * 交易日期
	 */
	private String transDate;
	/**
	 * 交易时间存在标识
	 */
	private boolean isTimeExist;
	/**
	 * 交易时间（hhmmss）
	 */
	private String transTime;
	/**
	 * 国家代码存在标识
	 */
	private boolean isCntCodeExist;
	/**
	 * 国家代码(9F1A)
	 */
	private String cntCode;
	/**
	 * 货币代码存在标识
	 */
	private boolean isCurExist;
	/**
	 * 货币代码(5F2A)
	 */
	private String curCode;
	/**
	 * 交易计数器存在标识
	 */
	private boolean isAtcExist;
	/**
	 * 交易计数器(9F36)
	 */
	private String atc;
	/**
	 * 交易类型存在标识
	 */
	private boolean is9Cexist;
	/**
	 * 交易类型(9C)
	 */
	private String serveType;
	/**
	 * 商户名称存在标识
	 */
	private boolean isMerchNameExist;
	/**
	 * 商户名称(9F4E)
	 */
	private String merchName;
	/**
	 * 本结构中未定义的其它数据元按照TLV 列表的格式保存在tlv中
	 */
	private String tlv;

	public boolean isAmtExist() {
		return isAmtExist;
	}

	public void setAmtExist(boolean isAmtExist) {
		this.isAmtExist = isAmtExist;
	}

	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

	public boolean isOtherAmtExist() {
		return isOtherAmtExist;
	}

	public void setOtherAmtExist(boolean isOtherAmtExist) {
		this.isOtherAmtExist = isOtherAmtExist;
	}

	public String getOtherAmt() {
		return otherAmt;
	}

	public void setOtherAmt(String otherAmt) {
		this.otherAmt = otherAmt;
	}

	public boolean isDateExist() {
		return isDateExist;
	}

	public void setDateExist(boolean isDateExist) {
		this.isDateExist = isDateExist;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public boolean isTimeExist() {
		return isTimeExist;
	}

	public void setTimeExist(boolean isTimeExist) {
		this.isTimeExist = isTimeExist;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public boolean isCntCodeExist() {
		return isCntCodeExist;
	}

	public void setCntCodeExist(boolean isCntCodeExist) {
		this.isCntCodeExist = isCntCodeExist;
	}

	public String getCntCode() {
		return cntCode;
	}

	public void setCntCode(String cntCode) {
		this.cntCode = cntCode;
	}

	public boolean isCurExist() {
		return isCurExist;
	}

	public void setCurExist(boolean isCurExist) {
		this.isCurExist = isCurExist;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}

	public boolean isAtcExist() {
		return isAtcExist;
	}

	public void setAtcExist(boolean isAtcExist) {
		this.isAtcExist = isAtcExist;
	}

	public String getAtc() {
		return atc;
	}

	public void setAtc(String atc) {
		this.atc = atc;
	}

	public boolean isIs9Cexist() {
		return is9Cexist;
	}

	public void setIs9Cexist(boolean is9Cexist) {
		this.is9Cexist = is9Cexist;
	}

	public String getServeType() {
		return serveType;
	}

	public void setServeType(String serveType) {
		this.serveType = serveType;
	}

	public boolean isMerchNameExist() {
		return isMerchNameExist;
	}

	public void setMerchNameExist(boolean isMerchNameExist) {
		this.isMerchNameExist = isMerchNameExist;
	}

	public String getMerchName() {
		return merchName;
	}

	public void setMerchName(String merchName) {
		this.merchName = merchName;
	}

	public String getTlv() {
		return tlv;
	}

	public void setTlv(String tlv) {
		this.tlv = tlv;
	}

}
