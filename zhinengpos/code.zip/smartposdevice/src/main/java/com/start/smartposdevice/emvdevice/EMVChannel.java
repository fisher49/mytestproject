package com.start.smartposdevice.emvdevice;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * EMV卡类型枚举。
 */
public enum EMVChannel implements Parcelable{
	/**
	 * 接触式卡
	 */
	ICC,
	/**
	 * 接近式卡
	 */
	PICC
	;
	/**
	 * 反序列化
	 * 实现从Parcel容器中读取传递数据值，封装成Parcelable对象返回逻辑层
	 */
	public static final Creator<EMVChannel> CREATOR = new Parcelable.Creator<EMVChannel>() {

		@Override
		public EMVChannel createFromParcel(Parcel source) {
			return EMVChannel.values()[source.readInt()];
		}

		@Override
		public EMVChannel[] newArray(int size) {
			return new EMVChannel[size];
		}
	};
	@Override
	public int describeContents() {
		return 0;
	}

	/**
	 * 将EMVChannel对象序列化为一个Parcel对象
	 *
	 * @param arg0 Parcel流
	 * @param arg1 需序列化的数据.
	 */
	@Override
	public void writeToParcel(Parcel arg0, int arg1) {
		arg0.writeInt(ordinal());
	}
}
