package com.start.smartposdevice.emvdevice;

import com.start.smartposdevice.emvdevice.EMVConstant.FLOW;

/**
 * EMV流程中需外部传入的交易流程相关数据
 */
public class EMVData {
	/**
	 * 交易金额。12字节的ASCII码
	 */
	private String amount;
	/**
	 * 交易类型。银联规范要求
	 */
	private byte tag9Value;
	/**
	 * 交易日期。YYYYMMDD, 8字节ASCII码，例如：“20150701”
	 */
	private String transDate;
	/**
	 * 交易时间。HHMMSS,6字节ASCII码，例如：“154920”
	 */
	private String transTime;
	/**
	 * 交易序号。 6字节ASCII码
	 */
	private String transNo;
	/**
	 * 是否支持国密。 <b>true</b>:支持， <b>false</b>：不支持
	 */
	private boolean isSupportSM;
	/**
	 * 是否执行脱机数据认证。  <b>false</b>:不执行 ，<b>true</b>:执行
	 * <p>插卡的EMV流程使用，完成流程设为true，简易流程设置为false
	 */
	private boolean isCardAuth;
	/**
	 * 是否强制联机。 <b>true</b>:是， <b>false</b>:否,
	 * <p>非接交易有效，设置为1则联机完成交易，0则走正常的电子现金交易流程
	 */
	private boolean isForceOnline;
	/**
	 * 是否支持电子现金交易。 <b>true</b>:支持， <b>false</b>：不支持
	 */
	private boolean isSupportEC;
	/**
	 * 是否执行CVM。<p>非指定账户圈存、现金圈存交易需设置为0，其他交易设置为1
	 */
	private boolean isSupportCvm;
	/**
	 * 交易流程
	 */
	private FLOW flow;
	/**
	 * 通道类型
	 */
	private EMVChannel channel;

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public byte getTag9Value() {
		return tag9Value;
	}

	public void setTag9Value(byte tag9Value) {
		this.tag9Value = tag9Value;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public String getTransNo() {
		return transNo;
	}

	public void setTransNo(String transNo) {
		this.transNo = transNo;
	}

	public boolean isSupportSM() {
		return isSupportSM;
	}

	public void setSupportSM(boolean isSupportSM) {
		this.isSupportSM = isSupportSM;
	}

	public boolean isCardAuth() {
		return isCardAuth;
	}

	public void setCardAuth(boolean isCardAuth) {
		this.isCardAuth = isCardAuth;
	}

	public boolean isForceOnline() {
		return isForceOnline;
	}

	public void setForceOnline(boolean isForceOnline) {
		this.isForceOnline = isForceOnline;
	}

	public boolean isSupportEC() {
		return isSupportEC;
	}

	public void setSupportEC(boolean isSupportEC) {
		this.isSupportEC = isSupportEC;
	}

	public boolean isSupportCvm() {
		return isSupportCvm;
	}

	public void setSupportCvm(boolean isSupportCvm) {
		this.isSupportCvm = isSupportCvm;
	}

	public FLOW getFlow() {
		return flow;
	}

	public void setFlow(FLOW flow) {
		this.flow = flow;
	}

	public EMVChannel getChannel() {
		return channel;
	}

	public void setChannel(EMVChannel channel) {
		this.channel = channel;
	}

}
