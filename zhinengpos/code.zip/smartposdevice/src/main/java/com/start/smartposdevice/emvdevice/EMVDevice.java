package com.start.smartposdevice.emvdevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;
import com.start.smartposdevice.OperationListener;

import java.nio.ByteBuffer;
import java.util.List;

/**
 * EMV内核操作接口
 */
public interface EMVDevice extends Device{

	/**
	 * 接触式IC卡
	 */
	public static final int CARD_TYPE_SMARTCARD = 2;

	/**
	 * 非接触式IC卡
	 */
	public static final int CARD_TYPE_RFCARD = 4;

	/**
	 * 寻卡
	 * @param readType 卡片类型。{@link #CARD_TYPE_SMARTCARD CARD_TYPE_SMARTCARD},{@link #CARD_TYPE_RFCARD CARD_TYPE_RFCARD}
	 * @param timeout 寻卡超时时间
	 * @param listener 寻卡监听器
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void readCard(int readType, int timeout, OperationListener listener) throws DeviceException;

	/**
	 * 停止寻卡
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void stopReadCard() throws DeviceException;

	/**
	 * 配置EMV内核
	 * @param config 配置参数
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void setTermConfig(EMVParaConfig config) throws DeviceException;

	/**
	 * 读取EMV内核配置参数
	 * @return 配置参数
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	EMVParaConfig getTermConfig() throws DeviceException;

	/**
	 * EMV流程处理
	 * @param transData 交易数据
	 * @param listener EMV催流程监听器
	 * @return 交易结果
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	int process(EMVData transData, EMVListener listener) throws DeviceException;

	/**
	 * 设置EMV内核中的数据元
	 * @param tag 数据元标签名称
	 * @param value 数据元
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void setTlv(int tag, byte[] value) throws DeviceException;

	/**
	 * 读取EMV内核中的数据元
	 * @param tag 数据元标签名称
	 * @return 数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] getTlv(int tag) throws DeviceException;

	/**
	 * 读取卡片电子现金余额
	 * @param channel 卡片类型。{@link #CARD_TYPE_SMARTCARD CARD_TYPE_SMARTCARD},{@link #CARD_TYPE_RFCARD CARD_TYPE_RFCARD}
	 * @return 金额。BCD码
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	long getEcBalance(EMVChannel channel) throws DeviceException;

	/**
	 * 读取卡片交易日志
	 * @param channel 卡片类型 {@link #CARD_TYPE_SMARTCARD CARD_TYPE_SMARTCARD},{@link #CARD_TYPE_RFCARD CARD_TYPE_RFCARD}
	 * @return 交易日志。具体数据参考{@link EMVCardLog EMVCardLog}中数据元定义
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	List<String> readLogRecord(EMVChannel channel) throws DeviceException;

	/**
	 * 为EMV内核装载一组AID数据
	 * @param param AID数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void setAidParam(EMVParaAID param) throws DeviceException;

	/**
	 * 读取EMV内核当前配置的所有AID数据
	 * @return AID数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	List<EMVParaAID> getAidParam() throws DeviceException;

	/**
	 * 清空EMV内核AID配置
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void clearAid() throws DeviceException;

	/**
	 * 为EMV内核添加一组公钥数据
	 * @param capk 公钥数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void setCapk(EMVParaCAPK capk) throws DeviceException;

	/**
	 * 读取EMV内核当前存储的所有公钥数据
	 * @return 公钥数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	List<EMVParaCAPK> getCapk() throws DeviceException;

	/**
	 * 清空EMV内核公钥数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void clearCapk() throws DeviceException;

	/**
	 * 从EMV内核中删除一组指定的AID
	 * @param aid 指定AID的名称
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void delAID(String aid) throws DeviceException;

	/**
	 * 从EMV内核中删除一组指定的公钥数据
	 * @param rid 公钥rid
	 * @param keyID 公钥索引
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void delCapKey(String rid, int keyID) throws DeviceException;

	/**
	 * 向卡片发送指令获取数据
	 * @param tagName 获取数据的tag
	 * @param data 获取的tag的值域
	 * @return 响应状态码。如 "0x9000 - 成功"
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	int  getDataFromCard(String tagName, ByteBuffer data) throws DeviceException;

	/**
	 * 返回EMV内核版本信息
	 * @param type 版本类型。<b>0</b> 认证版本 ， <b>1</b> 发行版本
	 * @return 版本信息
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String  getKernelVersion(int type) throws DeviceException;

	/**
	 * 打印内核调试日志开关
	 * @param value 开关标识
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void switchKernelDebugLog (boolean value) throws DeviceException;

	/*
	 * 从TLV串中查找指定标签的数据
	 * @param tlvData TLV字符串
	 * @param tagName 标签名称
	 * @param value 指定标签的数据
	 * @return <b>true</b>成功，<b>false</b>失败
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
//	boolean  getValueFromTLV(byte[] tlvData, String tagName, ByteBuffer value) throws DeviceException;
}
