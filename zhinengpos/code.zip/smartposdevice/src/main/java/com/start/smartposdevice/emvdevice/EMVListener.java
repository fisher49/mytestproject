package com.start.smartposdevice.emvdevice;

import java.nio.ByteBuffer;
import java.util.List;

/**
 * EMV处理流程监听器接口
 */
public interface EMVListener {

	/**
	 * 应用选择
	 * @param appNameList 应用列表集合
	 * @param isFirstSelect 是否第一次选择应用
	 * @return 所选应用的索引， 如果出错返回<b>-1</b>。
	 */
	int onWaitAppSelect(List<String> appNameList, boolean isFirstSelect);

	/**
	 * 确认卡号
	 * @param cardno 卡号
	 * @return <b>0</b>：确认，其他取消
	 */
	int onConfirmCardNo(String cardno);

	/**
	 * 身份认证
	 * @param certType 证件类型
	 * @param certValue 证件内容
	 * @return <b>0</b>：确认，其他取消
	 */
	int onCertVerfiy(String certType, String certValue);

	/**
	 * 输入密码
	 * @param isOnlinePin 是否联机交易
	 * @param offlinePinLeftTimes 脱机密码剩余次数
	 * @param pin 读取的pinblock。
	 * @return <b>0</b>：输入成功，<b>1</b>：bypass，<b>-1</b>：取消，<b>-2</b>：超时
	 */
	int onCardHolderPwd(boolean isOnlinePin, int offlinePinLeftTimes, ByteBuffer pin);

	/**
	 * 联机交易
	 * @return 联机结果 <b>0</b>:联机成功，<b>-1</b>联机失败
	 */
	int onOnlineProc();

	/**
	 * 显示信息
	 * @param message 显示内容
	 */
	void onShowMessage(String message);

	/**
	 * 键盘输入
	 * @param keyCode 键盘输入键值
	 */
	void onSendKey(int keyCode);

	/**
	 * 持卡人选择用于支付该笔交易的帐户类型。
	 * @return 持卡人帐户类型。
	 * <ul><li>00 默认-未指定</li>
	 * <li>10 储蓄账户</li>
	 * <li>20 支票账户/借记账户</li>
	 * <li>30 信用账户</li>
	 * </ul>
	 */
	int onSelectAccountType();
}
