package com.start.smartposdevice.emvdevice;

import com.start.smartposdevice.OperationResult;

/**
 * EMV处理结果
 */
public interface EMVOperationResult extends OperationResult{

	/**
	 * 获取IC卡类型
	 * @return 卡类型
     */
	int getCardType();
	
}
