package com.start.smartposdevice.emvdevice;

/**
 * EMV内核配置参数
 */
public class EMVParaConfig {

	/**
	 * 参考货币代码和交易代码转换系数
	 */
	private long referCurrCon;
	/**
	 * 商户名
	 */
	private String merchName;
	/**
	 * 商户类别码(没要求可不设置)
	 */
	private String merchCateCode;
	/**
	 * 商户标志(商户号)
	 */
	private String merchId;
	/**
	 * 终端标志(POS号)
	 */
	private String termId;
	/**
	 * 终端类型
	 */
	private int terminalType;
	/**
	 * 终端性能
	 */
	private String capability;
	/**
	 * 终端扩展性能
	 */
	private String exCapability;
	/**
	 * 交易货币代码指数
	 */
	private int transCurrExp;
	/**
	 * 参考货币指数
	 */
	private int referCurrExp;
	/**
	 * 参考货币代码
	 */
	private String referCurrCode;
	/**
	 * 终端国家代码
	 */
	private String countryCode;
	/**
	 * 当前交易类型
	 */
	private String transCurrCode;
	/**
	 * 商户强制联机(1 表示总是联机交易)
	 */
	private int transType;
	/**
	 * 商户强制联机(1 表示总是联机交易)
	 */
	private int forceOnline;
	/**
	 * 密码检测前是否读重试次数
	 */
	private int getDataPIN;
	/**
	 * 是否支持PSE选择方式
	 */
	private int surportPSESel;
	/**
	 * 是否基于卡片AIP进行风险管理。
	 * <ul>
	 *     <li><b>0</b>用卡片AIP</li>
	 *     <li><b>1</b>用终端AIP</li>
	 * </ul>默认为0
	 */
	private int useTermAIPFlg;
	/**
	 * 终端是否强制进行风险管理。
	 * <ul>
	 *     <li><b>byte1-bit4</b>为1：强制进行风险管理</li>
	 *     <li><b>byte1-bit4</b>为0：不进行风险管理</li>
	 * </ul>
	 * 默认两个字节全为0
	 */
	private byte[] termAIP;
	// whether bypass all other pin when one pin has been bypassed 1-Yes, 0-No
	/**
	 * whether bypass all other pin when one pin has been bypassed
	 * <p><b>1</b>-Yes, <b>0</b>-No</p>
	 */
	private int bypassAllFlg;
	/**
	 * <b>0</b>-不支持，<b>1</b>－支持，默认支持
	 */
	private int bypassPin;
	/**
	 * <b>0</b>-online data capture, <b>1</b>-batch capture
	 */
	private int batchCapture;
	/**
	 * <b>0</b>-不支持Advice，<b>1</b>-支持Advice
	 */
	private int adviceFlg;
	/**
	 * 脚本模式
	 */
	private int scriptMethod;
	/**
	 * 商户强制接受
	 * <p>1-ForceAccept</p>
	 */
	private int forceAccept;
	/**
	 * 返还
	 */
	private String reserve;
	/**
	 * 电子现金终端支持指示器。
	 * <p><b>1</b>-存在</p>
	 */
	private int ECTSIFlg;
	/**
	 * 电子现金终端支持指示器。
	 * <p><b>1</b>-支持</p>
	 */
	private int ECTSIVal;
	/**
	 * 电子现金终端交易限额。
	 * <p><b>1</b>-存在</p>
	 */
	private int ECTTLFlg;
	/**
	 * 电子现金终端交易限额
	 */
	private long ECTTLVal;
	/**
	 * 接口设备（IFD）序列号（固定8位）
	 */
	private String ifdSerialNumber;

	public long getReferCurrCon() {
		return referCurrCon;
	}

	public void setReferCurrCon(long referCurrCon) {
		this.referCurrCon = referCurrCon;
	}

	public String getMerchName() {
		return merchName;
	}

	public void setMerchName(String merchName) {
		this.merchName = merchName;
	}

	public String getMerchCateCode() {
		return merchCateCode;
	}

	public void setMerchCateCode(String merchCateCode) {
		this.merchCateCode = merchCateCode;
	}

	public String getMerchId() {
		return merchId;
	}

	public void setMerchId(String merchId) {
		this.merchId = merchId;
	}

	public String getTermId() {
		return termId;
	}

	public void setTermId(String termId) {
		this.termId = termId;
	}

	public int getTerminalType() {
		return terminalType;
	}

	public void setTerminalType(int terminalType) {
		this.terminalType = terminalType;
	}

	public String getCapability() {
		return capability;
	}

	public void setCapability(String capability) {
		this.capability = capability;
	}

	public String getExCapability() {
		return exCapability;
	}

	public void setExCapability(String exCapability) {
		this.exCapability = exCapability;
	}

	public int getTransCurrExp() {
		return transCurrExp;
	}

	public void setTransCurrExp(int transCurrExp) {
		this.transCurrExp = transCurrExp;
	}

	public int getReferCurrExp() {
		return referCurrExp;
	}

	public void setReferCurrExp(int referCurrExp) {
		this.referCurrExp = referCurrExp;
	}

	public String getReferCurrCode() {
		return referCurrCode;
	}

	public void setReferCurrCode(String referCurrCode) {
		this.referCurrCode = referCurrCode;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getTransCurrCode() {
		return transCurrCode;
	}

	public void setTransCurrCode(String transCurrCode) {
		this.transCurrCode = transCurrCode;
	}

	public int getTransType() {
		return transType;
	}

	public void setTransType(int transType) {
		this.transType = transType;
	}

	public int getForceOnline() {
		return forceOnline;
	}

	public void setForceOnline(int forceOnline) {
		this.forceOnline = forceOnline;
	}

	public int getGetDataPIN() {
		return getDataPIN;
	}

	public void setGetDataPIN(int getDataPIN) {
		this.getDataPIN = getDataPIN;
	}

	public int getSurportPSESel() {
		return surportPSESel;
	}

	public void setSurportPSESel(int surportPSESel) {
		this.surportPSESel = surportPSESel;
	}

	public int getUseTermAIPFlg() {
		return useTermAIPFlg;
	}

	public void setUseTermAIPFlg(int useTermAIPFlg) {
		this.useTermAIPFlg = useTermAIPFlg;
	}

	public byte[] getTermAIP() {
		return termAIP;
	}

	public void setTermAIP(byte[] termAIP) {
		this.termAIP = termAIP;
	}

	public int getBypassAllFlg() {
		return bypassAllFlg;
	}

	public void setBypassAllFlg(int bypassAllFlg) {
		this.bypassAllFlg = bypassAllFlg;
	}

	public int getBypassPin() {
		return bypassPin;
	}

	public void setBypassPin(int bypassPin) {
		this.bypassPin = bypassPin;
	}

	public int getBatchCapture() {
		return batchCapture;
	}

	public void setBatchCapture(int batchCapture) {
		this.batchCapture = batchCapture;
	}

	public int getAdviceFlg() {
		return adviceFlg;
	}

	public void setAdviceFlg(int adviceFlg) {
		this.adviceFlg = adviceFlg;
	}

	public int getScriptMethod() {
		return scriptMethod;
	}

	public void setScriptMethod(int scriptMethod) {
		this.scriptMethod = scriptMethod;
	}

	public int getForceAccept() {
		return forceAccept;
	}

	public void setForceAccept(int forceAccept) {
		this.forceAccept = forceAccept;
	}

	public String getReserve() {
		return reserve;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public int getECTSIFlg() {
		return ECTSIFlg;
	}

	public void setECTSIFlg(int eCTSIFlg) {
		ECTSIFlg = eCTSIFlg;
	}

	public int getECTSIVal() {
		return ECTSIVal;
	}

	public void setECTSIVal(int eCTSIVal) {
		ECTSIVal = eCTSIVal;
	}

	public int getECTTLFlg() {
		return ECTTLFlg;
	}

	public void setECTTLFlg(int eCTTLFlg) {
		ECTTLFlg = eCTTLFlg;
	}

	public long getECTTLVal() {
		return ECTTLVal;
	}

	public void setECTTLVal(long eCTTLVal) {
		ECTTLVal = eCTTLVal;
	}

	public void setIfdSerialNumber(String ifdSerialNumber) {
		this.ifdSerialNumber = ifdSerialNumber;
	}

	public String getIfdSerialNumber() {
		return ifdSerialNumber;
	}
}
