package com.start.smartposdevice.emvdevice;

public enum EMVResult {
	/**
	 * 联机批准
	 */
	ONLINE_APPROVED,
	/**
	 * 联机拒绝
	 */
	ONLINE_DENIED,
	/**
	 * 脱机批准
	 */
	OFFLINE_APPROVED,
	/**
	 * 脱机拒绝
	 */
	OFFLINE_DENIED,
	/**
	 * 主机批准，卡片拒绝
	 */
	ONLINE_CARD_DENIED,
	/**
	 * 异常
	 */
	ABORT_TERMINATED,
	/**
	 * 申请联机
	 */
	ARQC,
	/**
	 * 简化流程结束
	 */
	SIMPLE_FLOW_END
	;
}
