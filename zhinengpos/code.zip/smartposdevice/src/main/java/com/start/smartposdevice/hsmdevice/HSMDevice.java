package com.start.smartposdevice.hsmdevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;

import javax.security.auth.x500.X500Principal;

/**
 * 硬加密模块用于操作硬加密设备，包括设备操作方法接口。
 */
public interface HSMDevice extends Device{

	/**
	 * 证书格式
	 * <p>
	 * PEM格式
	 */
	public static final int CERT_FORMAT_PEM = 0;

	/**
	 * 证书格式
	 * <p>
	 * DER格式
	 */
	public static final int CERT_FORMAT_DER = 1;

	/**
	 * 密钥算法
	 * <p>
	 * RSA算法。
	 */
	public static final int ALGORITHM_RSA = 0;

	/**
	 * 哈希算法
	 * <p>
	 * SHA1算法。
	 */
	public static final int ALGORITHM_SHA1 = 1;

	/**
	 * 非对称加密算法
	 * <p>
	 * SM2算法。
	 */
	public static final int ALGORITHM_SM2 = 2;

	/**
	 * 哈希算法
	 * <p>
	 * SM3算法。
	 */
	public static final int ALGORITHM_SM3 = 3;

	/**
	 * 终端所有者根证书
	 */
	public static final int CERT_TYPE_TERMINAL_OWNER = 1;
	/**
	 * 终端自己的公钥证书
	 */
	public static final int CERT_TYPE_PUBLIC_KEY = 2;
	/**
	 * 终端应用根证书。该证书用于验证所有应用签名的合法性。
	 */
	public static final int CERT_TYPE_APP_ROOT = 3;
	/**
	 * 终端SSL通讯根证书。该证书用于验证服务器的合法性。
	 */
	public static final int CERT_TYPE_COMM_ROOT = 4;

	/**
	 * 获取随机数。从安全模块返回真随机数
	 * @param length 需要返回随机数的长度 小于 64
	 * @return 随机数
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] generateRandom(int length) throws DeviceException;

	/**
	 * 生成密钥对。让安全模块生成密钥对
	 * @param aliasPrivateKey 需要生成的私钥（密钥对）的别名
	 * @param algorithm 密钥对支持的算法
	 * @param keySize 密钥长度，目前只支持2048位
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void generateKeyPair(String aliasPrivateKey, int algorithm, int keySize) throws DeviceException;

	/**
	 * 删除密钥对。删除终端私钥（密钥对）
	 * @param aliasPrivateKey 私钥（密钥对）别名
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void deleteKeyPair(String aliasPrivateKey) throws DeviceException;

	/**
	 * 使用密钥对加密数据。使用终端私钥加密数据，加密结果默认使用PKCS1Padding
	 * @param aliasPrivateKey 私钥别名
	 * @param algorithm 加密算法
	 * @param Data 加密数据明文
	 * @return 加密结果
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] encrypt(String aliasPrivateKey, int algorithm, byte[] Data) throws DeviceException;

	/**
	 * 使用密钥对解密数据。使用终端私钥解密数据。解密结果默认使用PKCS1Padding
	 * @param aliasPrivateKey 私钥别名
	 * @param algorithm 加密算法
	 * @param encrypedData 解密数据密文
	 * @return 解密结果
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] decrypt(String aliasPrivateKey, int algorithm, byte[] encrypedData) throws DeviceException;

//	void injectCertificate(String alias, byte[] CertData, int dataFormat) throws DeviceException;

	/**
	 * 注入根 CA 公钥
	 * @param alias 证书的别名。
	 * @param aliasPrivateKey 证书对应的私钥别名。
	 * @param bufCert 证书数据
	 * @param dataFormat 证书数据格式（目前只支持FORMAT_PEM）
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void injectPublicKeyCertificate(String alias, String aliasPrivateKey, byte[] bufCert, int dataFormat) throws DeviceException;

	/**
	 * 注入根证书接口。终端所有者证书，应用根证书和通讯根证书都是通过本方法注入
	 * @param certType 证书类型：
	 *                 <ul><li>1:终端所有者根证书</li>
	 *                 <li>3:终端应用根证书</li>
	 *                 <li>4:终端SSL通讯根证书</li>
	 *                 </ul>
	 *                 <p>见{@link #CERT_TYPE_TERMINAL_OWNER CERT_TYPE_TERMINAL_OWNER},
	 *                 {@link #CERT_TYPE_APP_ROOT CERT_TYPE_APP_ROOT},
	 *                 {@link #CERT_TYPE_COMM_ROOT CERT_TYPE_COMM_ROOT}</p>
	 * @param alias 证书别名
	 * @param bufCert 证书数据流
	 * @param dataFormat 数据流格式
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void injectRootCertificate(int certType, String alias, byte[] bufCert, int dataFormat) throws DeviceException;

	/**
	 * 获取证书。
	 * @param certType 证书类型 <p>见{@link #CERT_TYPE_TERMINAL_OWNER CERT_TYPE_TERMINAL_OWNER}等</p>
	 * @param alias 证书别名
	 * @param dataFormat 数据流格式
	 * @return 证书数据流
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] getCertificate(int certType, String alias, int dataFormat) throws DeviceException;

	/**
	 * 删除证书
	 * @param certType 证书类型 <p>见{@link #CERT_TYPE_TERMINAL_OWNER CERT_TYPE_TERMINAL_OWNER}等</p>
	 * @param alias 证书别名
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void deleteCertificate(int certType, String alias) throws DeviceException;

	/**
	 * 生成终端公钥的证书签名请求CSR
	 * @param aliasPrivateKey 私钥别名
	 * @param subject CSR中的主体名称
	 * @return PEM格式的CSR数据流
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] generateCSR(String aliasPrivateKey, X500Principal subject) throws DeviceException;

	/**
	 * 返回硬件加密接口剩余或可用的空闲空间。
	 * @return 空间大小，单位为byte。
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	long getFreeSpace() throws DeviceException;

	/**
	 * 检查安全模块是否已经触发。 硬件安全模块有自动保护机制，如果发生对安全模块的攻击，会自动触发自毁并删除所有敏感信息。
	 * @return <b>true</b>触发，<b>false</b> 未触发
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	boolean isTampered() throws DeviceException;

	/**
	 * 计算HASH校验码
	 * @param algorithm Hash算法。见{@link #ALGORITHM_SHA1 ALGORITHM_SHA1},{@link #ALGORITHM_SM3 ALGORITHM_SM3}
	 * @param Data 原始数据
	 * @return Hash校验码
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] calculateHashCode(int algorithm, byte[] Data) throws DeviceException;
}
