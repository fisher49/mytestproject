package com.start.smartposdevice.leddevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;

/**
 * 定义了LED设备的接口
 */
public interface LedDevice extends Device{

    /**
     * LED设备
     * <p>
     * 红灯
     */
    public static final int LED_RED = 1;

    /**
     * LED设备
     * <p>
     * 绿灯
     */
    public static final int LED_GREEN = 2;

    /**
     * LED设备
     * <p>
     * 黄灯
     */
    public static final int LED_YELLOW = 4;

    /**
     * LED设备
     * <p>
     * 蓝灯
     */
    public static final int LED_BLUE = 8;

    /**
     * LED设备
     * <p>
     * 全部
     */
    public static final int LED_ALL = 15;

    /**
     * 使某个led灯进行闪烁，异步方法，可以被取消。
     * @param color 指定Led灯的颜色。见{@link #LED_RED LED_RED}等定义
     * @param delayTurnOn 指定Led灯所需要打开的时间。单位ms。
     * @param delayTurnOff 指定Led灯所需要关闭的时间。单位ms。
     * @param counts 周期，持续次数。
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
    void startBlink(byte color, long delayTurnOn, long delayTurnOff, int counts) throws DeviceException;

    /**
     * 打开led灯。LED灯会一直亮下去，直到调用turnOff()或Device.close()
     * @param color 指定Led灯的颜色。见{@link #LED_RED LED_RED}等定义
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
    void turnOn(byte color) throws DeviceException;

    /**
     * 关闭led灯。
     * @param color 指定Led灯的颜色。见{@link #LED_RED LED_RED}等定义
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
    void turnOff(byte color) throws DeviceException;
}
