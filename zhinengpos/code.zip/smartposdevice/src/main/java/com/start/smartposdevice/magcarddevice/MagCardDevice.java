package com.start.smartposdevice.magcarddevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;
import com.start.smartposdevice.OperationListener;

/**
 * 磁条卡读卡器设备接口
 */
public interface MagCardDevice extends Device{

	/**
	 * 监听刷卡事件
	 * @param listener 监听器
	 * @param timeout 监听超时时间
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void ListenForCardSwipe(OperationListener listener, int timeout) throws DeviceException;


//	void cancelListening() throws DeviceException;
	
}
