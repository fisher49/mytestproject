package com.start.smartposdevice.magcarddevice;

import com.start.smartposdevice.OperationResult;

/**
 * 磁条卡读卡器的操作结果。用以通知调用者/监听者本次调用的结果
 */
public interface MagCardOperationResult extends OperationResult{

	/**
	 * 获取磁道数据
	 * @param Track 磁道
	 * @return 磁道数据
     */
	byte[] getTrackData(int Track);
	
}
