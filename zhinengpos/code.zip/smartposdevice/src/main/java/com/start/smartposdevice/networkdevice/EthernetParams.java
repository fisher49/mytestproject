package com.start.smartposdevice.networkdevice;

/**
 * 以太网设置参数
 */
public class EthernetParams {

	/**
	 * 协议类型
	 * <ul>
	 *     <li>1.DHCP</li>
	 *     <li>2.STATIC</li>
	 * </ul>
	 */
	public int Mode;
	/**
	 * 本地IP
	 */
	public String IP;
	/**
	 * 掩码
	 */
	public String NetMask;
	/**
	 * 网关
	 */
	public String GateWay;
	/**
	 * 域名服务器1
	 */
	public String DNS1;
	/**
	 * 域名服务器2
	 */
	public String DNS2;

	/**
	 * 以太网设置参数构造器
	 * <p>参数见以上定义
     */
	public EthernetParams(int Mode, String IP, String NetMask, String GateWay, String DNS1, String DNS2){
		this.Mode = Mode;
		this.IP = IP;
		this.NetMask = NetMask;
		this.GateWay = GateWay;
		this.DNS1 = DNS1;
		this.DNS2 = DNS2;
	}
	
}
