package com.start.smartposdevice.networkdevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;

/**
 * 网络设备操作接口
 */
public interface NetworkDevice extends Device{

	/**
	 * 开启以太网
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void EthernetEnable() throws DeviceException;

	/**
	 * 关闭以太网
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void EthernetDisable() throws DeviceException;

	/**
	 * 获取以太网是否开启
	 * @return <b>true</b> 开启，<b>false</b>关闭
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	boolean EthernetIsReady() throws DeviceException;

	/**
	 * 配置以太网参数
	 * @param params 以太网配置信息，定义{@link EthernetParams EthernetParams}
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void EthernetConfig(EthernetParams params) throws DeviceException;

	/**
	 * 开启wifi
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void WifiEnable() throws DeviceException;

	/**
	 * 关闭wifi
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void WifiDisable() throws DeviceException;

	/**
	 * wifi是否已开启
	 * @return <b>true</b> 开启，<b>false</b>关闭
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	boolean WifiIsReady() throws DeviceException;;
	
}
