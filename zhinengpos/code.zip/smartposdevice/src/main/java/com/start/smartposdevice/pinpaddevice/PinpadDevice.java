package com.start.smartposdevice.pinpaddevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;
import com.start.smartposdevice.OperationListener;

/**
 * 密码键盘设备接口
 */
public interface PinpadDevice extends Device{

	/**
	 * 密钥类型：主密钥
	 */
	public static final int KEY_TYPE_TMK = 1;

	/**
	 * 密钥类型：PIK
	 */
	public static final int KEY_TYPE_PIK = 2;

	/**
	 * 密钥类型：MAK
	 */
	public static final int KEY_TYPE_MAK = 3;

	/**
	 * 密钥类型：TDK
	 */
	public static final int KEY_TYPE_TDK = 4;

	/**
	 * MAC算法类型：ECB算法
	 */
	public static final int ALG_MAC_METHOD_ECB = 1;

	/**
	 * MAC算法类型：X9.19算法,后补80
	 */
	public static final int ALG_MAC_METHOD_X919_80 = 2;

	/**
	 * MAC算法类型：X9.19算法 (不足后补 0x00)；移动支付项目使用
	 */
	public static final int ALG_MAC_METHOD_X919_X00 = 3;

	/**
	 * MAC算法类型：中总行扩展算法
	 */
	public static final int ALG_MAC_METHOD_BOCE = 4;

	/**
	 * MAC算法类型：X9.19算法,后补00
	 */
	public static final int ALG_MAC_METHOD_X919_00 = 5;

	/**
	 * MAC算法类型：异或后3DES
	 */
	public static final int ALG_MAC_METHOD_XOR_3DES = 6;

	/**
	 * PIN算法类型：联机PIN
	 */
	public static final int ALG_PIN_MODE_ONLINE = 0;

	/**
	 * PIN算法类型：脱机PIN
	 */
	public static final int ALG_PIN_MODE_OFFLINE = 2;

	/**
	 * 配置密码键盘。
	 * @param config 密码键盘配置参数
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void config(PinpadDeviceConfig config) throws DeviceException;

	/**
	 * 显示内容。仅适用于外置密码键盘
	 * @param lineNum 显示行号
	 * @param content 内容字符串
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void showContent(int lineNum, String content) throws DeviceException;

	/**
	 * 清除密码键盘显示。仅适用于外置密码键盘
	 * @param lineNum 清除内容所在行号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void clearContent(int lineNum) throws DeviceException;

	/**
	 * 装载密钥
	 * @param keyinfo 密钥数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void loadKey(PinpadDeviceKeyInfo keyinfo) throws DeviceException;

	/**
	 * 通过密钥POS灌装密钥。
	 * @param portNo 串口号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void loadMkeyByComm(int portNo) throws DeviceException;

	/**
	 * 计算MAC值。
	 * @param mackeyIndex macKEY索引
	 * @param mode mac算法 见{@link #ALG_MAC_METHOD_ECB ALG_MAC_METHOD_ECB}等定义
	 * @param data 原始数据
	 * @return mac码
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	byte[] calcMac(int mackeyIndex, int mode, byte[] data) throws DeviceException;

	/**
	 * 用户键入密码，获取PIN数据
	 * @param panBlock 参与计算的卡号
	 * @param pinkeyIndex pin密钥索引
	 * @param pinAlgMode pin算法类型
	 * @param listener 获取pin结果监听器
	 * @param keyListener 按键事件监听器
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void inputOnlinePin(String panBlock, int pinkeyIndex, int pinAlgMode, OperationListener listener, PinpadPressKeyListener keyListener) throws DeviceException;

	void cancelInputOnlinePin() throws DeviceException;

	/**
	 * 对称加密算法加密
	 * @param keyIndex 加密密钥索引
	 * @param data 加密原数据
	 * @return 加密密文
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	byte[] encrypt (int keyIndex, byte[] data) throws DeviceException;

	/**
	 * 将数据写入pinpad安全存储模块。
	 * @param index 写入位置。在pinpad安全模块中的偏移位置位置，以16字节为单位
	 * @param data 写入内容
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void writeRecord(int index, byte[] data) throws DeviceException;

	/**
	 * 从pinpad安全存储模块中读取数据。
	 * @param index 读取位置。 在pinpad安全模块中的偏移位置，以16字节为单位
	 * @param lenght 读取内容长度
	 * @return 读取的数据。
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	byte[] readRecord(int index, int lenght) throws DeviceException;

	/**
	 * 读取PINPad序列号。
	 * @return PINPad序列号。
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	String getSN() throws DeviceException;
}
