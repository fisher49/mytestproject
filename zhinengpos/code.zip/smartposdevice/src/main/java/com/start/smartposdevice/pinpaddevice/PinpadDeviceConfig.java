package com.start.smartposdevice.pinpaddevice;

/**
 * PINPAD设备配置参数
 */
public class PinpadDeviceConfig {

	/**
	 * 对称算法类型：DES
	 */
	public static final int ALG_SYMMETRICAL_DES = 0;

	/**
	 * 对称算法类型：SM4
	 */
	public static final int ALG_SYMMETRICAL_SM4 = 2;

//	public int mKeyIndex;
	
	public int timeout;
	
	public String supportPinLen;

	public int symmetricAlgorithmType;

	/**
	 * pinpad配置参数构建器
	 * @param timeout 密码输入的超时时间，单位秒
	 * @param supportPinLen 输入联机密码时支持的密码长度， 格式“0,4,6,8,10”
	 * @param symmetricAlgorithmType 对称算法类型。
	 *                                  见{@link #ALG_SYMMETRICAL_DES ALG_SYMMETRICAL_DES},
	 *                               {@link #ALG_SYMMETRICAL_SM4 ALG_SYMMETRICAL_SM4}
     */
	public PinpadDeviceConfig(int timeout, String supportPinLen, int symmetricAlgorithmType){
//		this.mKeyIndex = mKeyIndex;
		this.timeout = timeout;
		this.supportPinLen = supportPinLen;
		this.symmetricAlgorithmType = symmetricAlgorithmType;
	}

}
