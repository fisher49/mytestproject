package com.start.smartposdevice.pinpaddevice;

/**
 * 密钥数据
 */
public class PinpadDeviceKeyInfo {

	/**
	 * 密钥类型
	 * <p><b>1</b> – MKEY 主密钥
	 * <p><b>2</b> – PINKEY PIN密钥
	 * <p><b>3</b> – MACKEY MAC密钥
	 * <p><b>4</b> – TRACKKEY DES密钥
	 */
	public int keyType;

	/**
	 * 是否是密文
	 */
	public boolean isEncrypted;

	/**
	 * 主密钥索引
	 */
	public int mKeyIndex;

	/**
	 * 工作密钥索引
	 */
	public int wKeyIndex;

	/**
	 * 密钥数据
	 */
	public byte[] keyData;

	/**
	 * 密钥长度
	 */
	public int keyDataLen;

	/**
	 * 密钥校验码
	 */
	public byte[] kcvValue;

	/**
	 * 密钥校验码长度
	 */
	public int kcvValueLen;

	/**
	 * 密钥数据构造器
	 * <p>参数见以上定义
     */
	public PinpadDeviceKeyInfo (int keyType, boolean isEncrypted, int mKeyIndex, int wKeyIndex, 
			byte[] keyData, int keyDataLen, byte[] kcvValue, int kcvValueLen) {
		this.keyType = keyType;
		this.isEncrypted = isEncrypted;
		this.mKeyIndex = mKeyIndex;
		this.wKeyIndex = wKeyIndex;
		this.keyData = keyData;
		this.keyDataLen = keyDataLen;
		this.kcvValue = kcvValue;
		this.kcvValueLen = kcvValueLen;
	}
	
}
