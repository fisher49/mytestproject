package com.start.smartposdevice.pinpaddevice;

import com.start.smartposdevice.OperationResult;

/**
 * PINPAD设备的操作结果。用以通知调用者/监听者本次调用的结果
 */
public interface PinpadOperationResult extends OperationResult{

	/**
	 * 获取pin
	 * @return pin
     */
	byte[] getPinBlock();
}
