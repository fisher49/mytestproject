package com.start.smartposdevice.pinpaddevice;

/**
 * 密码键盘设备按键监听接口
 */
public interface PinpadPressKeyListener {

	/**
	 * 获取按键长度的回调
	 * @param length 按键长度
     */
	void pressKeyEvent(int length);
}
