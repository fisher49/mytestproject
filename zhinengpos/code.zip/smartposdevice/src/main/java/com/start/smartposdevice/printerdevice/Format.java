package com.start.smartposdevice.printerdevice;

import java.util.HashMap;

/**
 * 打印格式
 */
public class Format {
    /**
     * 下列常量定义了打印机条码的打印信息。
     * <p>
     * UPC-A条形码。
     */
    public static final int BARCODE_UPC_A = 0;

    /**
     * UPC-E条形码。
     */
    public static final int BARCODE_UPC_E = 1;

    /**
     * JAN13条形码。
     */
    public static final int BARCODE_JAN13 = 2;

    /**
     * JAN8条形码。
     */
    public static final int BARCODE_JAN8 = 3;

    /**
     * CODE39码。
     */
    public static final int BARCODE_CODE39 = 4;

    /**
     * TIF码。
     */
    public static final int BARCODE_ITF = 5;

    /**
     * CODABAR。
     */
    public static final int BARCODE_CODABAR = 6;

    /**
     * CODE93。
     */
    public static final int BARCODE_CODE93 = 7;

    /**
     * CODE128。
     */
    public static final int BARCODE_CODE128 = 8;

    /**
     * 没有HRI字符。
     */
    public static final int BARCODE_HRI_POS_NONE = 0;

    /**
     * HRI在条码上面。
     */
    public static final int BARCODE_HRI_POS_ABOVE = 1;

    /**
     * HRI字符在条码下面。
     */
    public static final int BARCODE_HRI_POS_BELOW = 2;

    /**
     * HRI字符在条码上下都有。
     */
    public static final int BARCODE_HRI_POS_BOTH = 3;

    /**
     * 打印位置信息。对字符及图形打印有效。
     * <p>
     * 左对齐打印
     */
    public static final int ALIGN_LEFT = 0;

    /**
     * 居中对齐打印
     */
    public static final int ALIGN_CENTER = 1;

    /**
     * 右对齐打印
     */
    public static final int ALIGN_RIGHT = 2;

    /**
     * 打印字符大小
     * <p>
     * 打印小号字体
     */
    public static final int FONT_SIZE_SMALL = 0;

    /**
     * 打印中号字体
     */
    public static final int FONT_SIZE_MEDIUM = 1;

    /**
     * 打印大号字体
     */
    public static final int FONT_SIZE_LARGE = 2;

    /**
     * 打印浓度。对字符，图形及条码打印都有效。
     * <p>
     * 淡
     */
    public static final int DENSITY_LIGHT = 0;
    /**
     * 中
     */
    public static final int DENSITY_MEDIUM = 1;
    /**
     * 深
     */
    public static final int DENSITY_DARK = 2;

    /**
     * 加粗效果。对字符打印有效。
     * <p>
     * 加粗
     */
    public static final int BOLD_ENABLE = 0;
    /**
     * 不加粗
     */
    public static final int BOLD_DISABLE = 1;

    /**
     * 反白效果。对字符打印有效。
     * <p>
     * 反白
     */
    public static final int REVERSE_ENABLE = 0;
    /**
     * 不反白
     */
    public static final int REVERSE_DISABLE = 1;

    /**
     * 上下倒置。对字符打印有效。
     * <p>
     * 上下倒置
     */
    public static final int INVERSION_ENABLE = 0;
    /**
     * 不倒置
     */
    public static final int INVERSION_DISABLE = 1;

    /**
     * 删除线效果。对字符打印有效。
     * <p>
     * 连续的删除线
     */
    public static final int LINE_THROUGH_CONTINUOUS = 0;
    /**
     * 断开的删除线
     */
    public static final int LINE_THROUGH_DISCONTINUOUS = 1;

    /**
     * 斜体。对字符打印有效。
     * <p>
     * 斜体
     */
    public static final int ITALIC_ENABLE = 0;
    /**
     * 非斜体
     */
    public static final int ITALIC_DISABLE = 1;


    private HashMap<String, Integer> mMap;

    public Format() {
        mMap = new HashMap<String, Integer>();
    }

    /**
     * 以键-值对的方式设置打印格式.
     * <p>目前定义的键-值如下所示：
     * <ol><li>打印浓度（density）
     * <p>对应的值为：{@link #DENSITY_LIGHT DENSITY_LIGHT},{@link #DENSITY_MEDIUM DENSITY_MEDIUM},{@link #DENSITY_DARK DENSITY_DARK},
     * <p>对字符，图形及条码打印都有效。
     * <li>加粗（bold）
     * <p>对应的值为：{@link #BOLD_ENABLE BOLD_ENABLE},{@link #BOLD_DISABLE BOLD_DISABLE},
     * <p>对字符打印有效。
     * <li>反白（reverse）
     * <p>对应的值为：{@link #REVERSE_ENABLE REVERSE_ENABLE},{@link #REVERSE_DISABLE REVERSE_DISABLE},
     * <p>对字符打印有效。
     * <li>上下倒置（inversion）
     * <p>对应的值为：{@link #INVERSION_ENABLE INVERSION_ENABLE},{@link #INVERSION_DISABLE INVERSION_DISABLE},
     * <p>对字符打印有效。
     * <li>删除线（line-through）
     * <p>对应的值为：{@link #LINE_THROUGH_CONTINUOUS LINE_THROUGH_CONTINUOUS},{@link #LINE_THROUGH_DISCONTINUOUS LINE_THROUGH_DISCONTINUOUS}
     * <p>对字符打印有效。
     * <li>大小（size）
     * <p>对应的值为：{@link #FONT_SIZE_SMALL FONT_SIZE_SMALL},{@link #FONT_SIZE_MEDIUM FONT_SIZE_MEDIUM},{@link #FONT_SIZE_LARGE FONT_SIZE_LARGE}
     * <p>对字符打印有效。
     * <li>对齐方式（align）
     * <p>对应的值为：{@link #ALIGN_LEFT ALIGN_LEFT ALIGN_LEFT}, {@link #ALIGN_CENTER ALIGN_CENTER}, {@link #ALIGN_RIGHT ALIGN_RIGHT}
     * <p>对字符及图形打印有效。
     * <li>斜体（italic）
     * <p>对应的值为：{@link #ITALIC_ENABLE ITALIC_ENABLE},{@link #ITALIC_DISABLE ITALIC_DISABLE}
     * <p>对字符打印有效。
     * <li>HRI字符的打印位置（HRI-location）
     * <p>对应的值为：如{@link #BARCODE_HRI_POS_NONE BARCODE_HRI_POS_NONE}等
     * <p>对条码打印有效。
     * <li>打印条码类型（barcode-type）
     * <p>对应的值为：如{@link #BARCODE_UPC_A BARCODE_UPC_A}等
     * <p>对条码打印有效。
     * </ol>
     * @param key   打印格式主键
     * @param value 打印格式值
     */
    public void setParameter(String key, int value){
        if (key.indexOf('=') != -1 || key.indexOf(';') != -1) {
            return;
        }
        mMap.put(key, value);
    };


    /**
     * 返回打印格式.
     *
     * @param key 传入主键
     * @return 打印格式
     */
    public int getParameter(String key){

        return mMap.get(key);
    };

    /**
     * 移除某一个参数
     *
     * @param key 传入主键
     *
     */
    public void remove(String key) {
        mMap.remove(key);
    }
    /**
     * 清除所有打印格式.
     *
     */
    public void clear(){
        mMap.clear();
    };
}
