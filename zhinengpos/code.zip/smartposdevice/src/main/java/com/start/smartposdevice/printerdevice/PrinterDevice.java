package com.start.smartposdevice.printerdevice;

import android.graphics.Bitmap;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;

/**
 * 打印机设备接口
 */
public interface PrinterDevice extends Device{

    /**
     * 打印机状态正常
     */
    public static final int STATUS_NORMAL = 0;
    
    /**
     * 打印机忙
     */
    public static final int STATUS_BUSY = 1;
    
    /**
     * 打印机缺纸
     */
    public static final int STATUS_OUT_OF_PAPER = 2;
    
    /**
     * 打印机过热
     */
    public static final int STATUS_HOT = 3;
    
    /**
     * 打印机其他异常
     */
    public static final int STATUS_ERR = 4;

    /**
     * 打印带格式文本
     * @param format 打印格式。参考{@link Format Format}
     * @param Text 打印内容
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
    void printText(Format format, String Text) throws DeviceException;

    /**
     * 打印位图
     * @param format 打印格式。参考{@link Format Format}
     * @param bitmap 位图数据
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
    void printBitmap(Format format, Bitmap bitmap) throws DeviceException;

    /**
     * 打印条码
     * @param format 打印格式。参考{@link Format Format}
     * @param Barcode 条码数据
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
    void printBarcode(Format format, String Barcode) throws DeviceException;

    /**
     * 获取打印机状态
     * @return 状态码。如{@link #STATUS_NORMAL STATUS_NORMAL}
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
    int getStatus() throws DeviceException;

    /**
     * 走纸
     * @throws DeviceException 见{@link DeviceException DeviceException}
     */
    void cutpaper() throws DeviceException; 
    
}
