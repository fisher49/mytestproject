package com.start.smartposdevice.psamdevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;

/**
 * PSAM卡读卡器接口
 */
public interface PSAMDevice extends Device{

	/**
	 * 卡片复位
	 * @return 复位数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] reset() throws DeviceException;

	/**
	 * 发送APDU数据
	 * @param APDU apdu指令
	 * @return 响应码
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] transmit(byte[] APDU) throws DeviceException;

	/**
	 * 设置ETU时间
	 * @param EtuValue ETU时间值
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void setETU(byte EtuValue) throws DeviceException;
	
}
