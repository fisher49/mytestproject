package com.start.smartposdevice.rfcarddevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;
import com.start.smartposdevice.OperationListener;

/**
 * 非接式IC卡读卡器模块用于操作读取非接式IC卡数据。
 * <p>非接读卡器的接口
 */
public interface RFCardDevice extends Device{

	/**
	 * 卡片类型
	 * <p>
	 * CPU卡
	 */
	public static final int CARD_TYPE_CPU = 0;

	/**
	 * 卡片类型
	 * <p>
	 * M1卡
	 */
	public static final int CARD_TYPE_MIFARE = 1;

	/**
	 * 寻卡
	 * @param listener 监听器
	 * @param timeout 寻卡超时时间
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void ListenForCardPresent(OperationListener listener, int timeout) throws DeviceException;

	/**
	 * 监听移卡
	 * @param listener 监听器
	 * @param timeout 移卡监听超时
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void ListenForCardAbsent(OperationListener listener, int timeout) throws DeviceException;

	/**
	 * 取消卡操作监听
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void cancelListening() throws DeviceException;

	/**
	 * 卡片链接
	 * @return 卡片的ATR数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	byte[] connect() throws DeviceException;

	/**
	 * 卡片断开链接
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void disconnect() throws DeviceException;

	/**
	 * 获取卡片类型
	 * @return 卡片类型。{@link #CARD_TYPE_CPU CARD_TYPE_CPU},{@link #CARD_TYPE_MIFARE CARD_TYPE_MIFARE}
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	int getCardType() throws DeviceException;

	/**
	 * 验证Mifare卡指定区域的KeyA
	 * @param sectorIndex 区域索引号
	 * @param key KeyA
	 * @return <b>true</b>成功,<b>false</b>失败
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	boolean verifyKeyA(int sectorIndex, byte[] key) throws DeviceException;

	/**
	 * 验证Mifare卡指定区域的KeyB
	 * @param sectorIndex 区域索引号
	 * @param key KeyB
	 * @return <b>true</b>成功,<b>false</b>失败
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	boolean verifyKeyB(int sectorIndex, byte[] key) throws DeviceException;

	/**
	 * Mifare卡数据加值
	 * @param sectorIndex 区域索引号
	 * @param blockOfSector 数据块号
	 * @param value 数值
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void increaseValue(int sectorIndex, int blockOfSector, int value) throws DeviceException;

	/**
	 * Mifare卡数据减值
	 * @param sectorIndex 区域索引号
	 * @param blockOfSector 数据块号
	 * @param value 数值
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void decreaseValue(int sectorIndex, int blockOfSector, int value) throws DeviceException;

	/**
	 * 读取分区中指定block的数据。
	 * @param sectorIndex 分区ID
	 * @param blockOfSector block索引号
	 * @return 读取的数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	byte[] readBlock(int sectorIndex,int blockOfSector) throws DeviceException;

	/**
	 * 对指定分区block写入数据。
	 * @param sectorIndex 分区ID
	 * @param blockOfSector block索引号
	 * @param buffer 数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void writeBlock(int sectorIndex,int blockOfSector, byte[] buffer) throws DeviceException;

	/**
	 * 在智能卡和读卡器之间传递信息。
	 * <p>如果在发送命令前，需要选卡、唤醒等操作，由底层自动实现。
	 * <br>如果与读卡器之间断开连接，不能执行APDU命令。</p>
	 * @param apdu APDU数据流
	 * @return 响应的APDU数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	byte[] transmit(byte[] apdu) throws DeviceException;
}
