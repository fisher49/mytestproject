package com.start.smartposdevice.serialportdevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;
import com.start.smartposdevice.OperationListener;

/**
 * 串口设备接口
 */
public interface SerialPortDevice extends Device{

	/**
	 * 设定串口波特率
	 * @param Baudrate 波特率
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void setBaudrate(int Baudrate) throws DeviceException;

	/**
	 * 发送串口数据
	 * @param data 发送的数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void send(byte[] data) throws DeviceException;

	/**
	 * 监听串口数据。并读取最多<b>length</b>长的数据
	 * @param length 读取数据的最大长度
	 * @param listener 监听器
	 * @param timeout 监听超时时间
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void ListenForReceive(int length, OperationListener listener, int timeout) throws DeviceException;
	
//	void cancelListening() throws DeviceException;
}
