package com.start.smartposdevice.serialportdevice;

import com.start.smartposdevice.OperationResult;

/**
 * 串口设备的操作结果。用以通知调用者/监听者本次调用的结果
 */
public interface SerialPortOperationResult extends OperationResult{

	/**
	 * 获取数据
	 * @return bytes数组数据
     */
	byte[] getData();
	
}
