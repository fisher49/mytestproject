package com.start.smartposdevice.smartcarddevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;
import com.start.smartposdevice.OperationListener;

/**
 * 接触式IC卡读卡器接口
 */
public interface SmartCardDevice extends Device{

	/**
	 * 寻卡
	 * @param listener 监听器
	 * @param timeout 监听超时
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void ListenForCardPresent(OperationListener listener, int timeout) throws DeviceException;

	/**
	 * 监听移卡事件
	 * @param listener 监听器
	 * @param timeout 监听超时
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	void ListenForCardAbsent(OperationListener listener, int timeout) throws DeviceException;
	
//	void cancelListening() throws DeviceException;

	/**
	 * 卡片链接
	 * @return 卡片的ATR数据
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] connect() throws DeviceException;

	/**
	 * 卡片断开链接
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void disconnect() throws DeviceException;

	/**
	 * apdu指令交互
	 * @param APDU apdu指令数据
	 * @return 响应码
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	byte[] transmit(byte[] APDU) throws DeviceException;
	
}
