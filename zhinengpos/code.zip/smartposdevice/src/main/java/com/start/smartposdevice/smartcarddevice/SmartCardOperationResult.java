package com.start.smartposdevice.smartcarddevice;

import com.start.smartposdevice.OperationResult;

/**
 * 智能卡读卡器的操作结果。用以通知调用者/监听者本次调用的结果
 */
public interface SmartCardOperationResult extends OperationResult{

}
