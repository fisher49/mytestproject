package com.start.smartposdevice.systemdevice;

import com.start.smartposdevice.Device;
import com.start.smartposdevice.DeviceException;

/**
 * 系统设备模块用于控制终端设备的一些通用模块和设备。
 */
public interface SystemDevice extends Device{
	
	/**
	 * 蜂鸣器提示音
	 * <p>
	 * 成功：一声
	 */
	public static final int BEEP_SUCC = 1;
	
	/**
	 * 蜂鸣器提示音
	 * <p>
	 * 错误：两声
	 */
	public static final int BEEP_ERR = 2;
	
	/**
	 * 蜂鸣器提示音
	 * <p>
	 * 故障：三声
	 */
	public static final int BEEP_FAULT = 3;
	
	/**
	 * 蜂鸣器提示音
	 * <p>
	 * 提醒：四声
	 */
	public static final int BEEP_PROMPT = 4;
	
	/**
	 * LED设备
	 * <p>
	 * 全不亮
	 */
	public static final int LED_NULL = 0;
	
	/**
	 * LED设备
	 * <p>
	 * 红灯亮
	 */
	public static final int LED_RED = 1;
	
	/**
	 * LED设备
	 * <p>
	 * 绿灯亮
	 */
	public static final int LED_GREEN = 2;
	
	/**
	 * LED设备
	 * <p>
	 * 黄灯亮
	 */
	public static final int LED_YELLOW = 4;
	
	/**
	 * LED设备
	 * <p>
	 * 蓝灯亮
	 */
	public static final int LED_BLUE = 8;
	
	/**
	 * LED设备
	 * <p>
	 * 全亮
	 */
	public static final int LED_ALL = 15;

	/**
	 * 蜂鸣器发声
	 * @param mode 蜂鸣模式
	 *             <p>{@link #BEEP_SUCC BEEP_SUCC},
	 *             {@link #BEEP_FAULT BEEP_FAULT},
	 *             {@link #BEEP_ERR BEEP_ERR},
	 *             {@link #BEEP_PROMPT BEEP_PROMPT},
	 *             </p>
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void beep(int mode) throws DeviceException;
	
//	void setLED(byte mode) throws DeviceException;

//	int getVersionCode() throws DeviceException;

	/**
	 * 获取终端序列号
	 * @return 序列号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getSerialNo() throws DeviceException;

	/**
	 * 静默安装APP
	 * @param filePath APK存储路径
	 * @return 应用包名
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String installApp(String filePath) throws DeviceException;

	/**
	 * 获取KSN号
	 * @return ksn号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getKsn() throws DeviceException;

	/**
	 * 获取驱动版本信息
	 * @return 版本号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getDriverVersion() throws DeviceException;

	/**
	 * 获取SDK版本信息
	 * @return 版本号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getCurSdkVersion() throws DeviceException;

	/**
	 * 更新系统时间
	 * @param Time 时间字符串，格式为yyyyMMddhhmmss
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void updateSystemTime(String Time) throws DeviceException;

	/**
	 * 获取存储路径
	 * @return 获取存储文件路径信息
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getStoragePath() throws DeviceException;

	/**
	 * 固件更新
	 * @param updateType 更新类型
	 *                   <ul>
	 *                   <li><b>0</b> - Android os更新</li>
	 *                   <li><b>1</b> - 驱动资源包更新</li>
	 *                   </ul>
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void update(int updateType) throws DeviceException;

	/**
	 * 读取IMSI号
	 * @return IMSI号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getIMSI() throws DeviceException;

	/**
	 * 读取IMEI号
	 * @return IMEI号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
	 */
	String getIMEI() throws DeviceException;

	/**
	 * 获取硬件版本号
	 * @return 版本号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getHardWireVersion() throws DeviceException;

	/**
	 * 获取安全固件版本信息
	 * @return 版本号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getSecurityDriverVersion() throws DeviceException;

	/**
	 * 获取制造商名称
	 * @return 制造商名称
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getManufacture() throws DeviceException;

	/**
	 * 获取终端型号
	 * @return 型号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getModel() throws DeviceException;

	/**
	 * 获取ANDROID版本信息
	 * @return 版本号
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getAndroidOsVersion() throws DeviceException;

	/**
	 * 获取终端ROM信息
	 * @return ROM信息
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getRomVersion() throws DeviceException;

	/**
	 * 获取终端内核信息
	 * @return 内核信息
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	String getAndroidKernelVersion() throws DeviceException;

	/**
	 * 重启终端
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	void reboot() throws DeviceException;

	/**
	 * 执行shell指令
	 * @param cmd shell指令
	 * @return <b>true</b>成功，<b>false</b>失败
	 * @throws DeviceException 见{@link DeviceException DeviceException}
     */
	boolean executeCmd(String cmd) throws DeviceException;
	
}