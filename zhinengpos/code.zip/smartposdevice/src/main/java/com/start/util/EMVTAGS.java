package com.start.util;

import java.io.ByteArrayOutputStream;

/**
 * PBOC EMV标签
 *
 * @author Administrator
 *
 */
public class EMVTAGS {
	/** 5A 主账号 */
	public static final byte[] EMVTAG_APP_PAN = combine(0x5A);
	/** 5F34 卡序列号 */
	public static final byte[] EMVTAG_APP_PAN_SN = combine(0x5F, 0x34);
	/** 5F24 应用失效日期 */
	public static final byte[] EMVTAG_APP_INVALID_DATE = combine(0x5F, 0x24);
	/** 57 二磁道信息 */
	public static final byte[] EMVTAG_TRACK2 = combine(0x57);
	/** 9F26 应用密文 TC AAC ARQC */
	public static final byte[] EMVTAG_AC = combine(0x9F, 0x26);
	/** 9F27 密文信息数据 */
	public static final byte[] EMVTAG_CID = combine(0x9F, 0x27);
	/** 9F10 发卡行应用数据 */
	public static final byte[] EMVTAG_IAD = combine(0x9F, 0x10);
	/** 9F37 不可预知数 */
	public static final byte[] EMVTAG_RND_NUM = combine(0x9F, 0x37);
	/** 9F36 ATC 应用交易计数器 */
	public static final byte[] EMVTAG_ATC = combine(0x9F, 0x36);
	/** 95 TVR 发卡行行为代码 */
	public static final byte[] EMVTAG_TVR = combine(0x95);
	/** 9A 交易日期 */
	public static final byte[] EMVTAG_TXN_DATE = combine(0x9A);
	/** 9C 交易类型 */
	public static final byte[] EMVTAG_TXN_TYPE = combine(0x9C);
	/** 9F02授权金额 */
	public static final byte[] EMVTAG_AMOUNT = combine(0x9F, 0x02);
	/** 5F2A 交易货币代码 */
	public static final byte[] EMVTAG_CURRENCY = combine(0x5F, 0x2A);
	/** 82 应用交互特征 */
	public static final byte[] EMVTAG_AIP = combine(0x82);
	/** 9F1A 终端国家代码 */
	public static final byte[] EMVTAG_COUNTRY_CODE = combine(0x9F, 0x1A);
	/** 9F03 其他金额 */
	public static final byte[] EMVTAG_OTHER_AMOUNT = combine(0x9F, 0x03);
	/** 9F33 终端性能 */
	public static final byte[] EMVTAG_TERM_CAP = combine(0x9F, 0x33);
	/** 9F34 持卡人验证结果 */
	public static final byte[] EMVTAG_CVM = combine(0x9F, 0x34);
	/** 9F34 持卡人验证结果 */
	public static final byte[] EMVTAG_TERM_TYPE = combine(0x9F, 0x35);
	/** 9F1E 接口设备序列号 */
	public static final byte[] EMVTAG_IFD = combine(0x9F, 0x1E);
	/** 84 专用文件名称 */
	public static final byte[] EMVTAG_DF = combine(0x84);
	/** 9F09应用版本号 */
	public static final byte[] EMVTAG_APP_VER = combine(0x9F, 0x09);
	/** 9F41交易序列计数器 */
	public static final byte[] EMVTAG_TXN_SN = combine(0x9F, 0x41);
	/** 9F63 卡产品标识 */
	public static final byte[] EMVTAG_CARD_ID = combine(0x9F, 0x63);
	/** 4F 卡片AID */
	public static final byte[] EMVTAG_AID = combine(0x4F);
	/** DF31 发卡行脚本结果 */
	public static final byte[] EMVTAG_SCRIPT_RESULT = combine(0xDF, 0x31);
	/** 8A授权响应码 */
	public static final byte[] EMVTAG_ARC = combine(0x8A);
	/** 5F28 发卡行国家代码 */
	public static final byte[] EMVTAG_ISS_COUNTRY_CODE = combine(0x5F, 0x28);
	/** 9F74电子现金发卡行授权码 */
	public static final byte[] EMVTAG_EC_AUTH_CODE = combine(0x9F, 0x74);
	/** 9F79 电子现金余额 */
	public static final byte[] EMVTAG_EC_BALANCE = combine(0x9F, 0x79);
	/** 9B 交易状态信息 */
	public static final byte[] EMVTAG_TSI = combine(0x9B);
	/** 50 应用标签 */
	public static final byte[] EMVTAG_APP_LABEL = combine(0x50);
	/** 9F12 应用名称 */
	public static final byte[] EMVTAG_APP_NAME = combine(0x9F, 0x12);
	/** 9F4E 商户名称 */
	public static final byte[] EMVTAG_CONTACT_NAME = combine(0x9F, 0x4E);
	/** 9F7B 终端交易限额 */
	public static final byte[] EMVTAG_LIMIT_BALANCE = combine(0x9F, 0x7B);// 当授权金额高于此限制时，该交易不为电子现金交易）
	/** 9F77 电子现金余额上限 */
	public static final byte[] EMVTAG_UP_LIMIT_BALANCE = combine(0x9F, 0x77);
	/** 8F 卡片中的公钥证书 */
	public static final byte[] EMVTAG_CAPK = combine(0x8F);

	/**
	 * 组织taglist列表方法，如： ous.write(combine(0x5A)); 或
	 * ous.write(combine(0x5F,0x34));
	 *
	 * @param bytes 标签有效字节码
	 * @return tag字节数组
	 */
	public static byte[] combine(int... bytes) {
		ByteArrayOutputStream bout = new ByteArrayOutputStream(4);
		for (int i = 0; i < bytes.length; i++) {
			bout.write(bytes[bytes.length - i - 1]);
		}
		for (int i = 0; i < (4 - bytes.length); i++) {
			bout.write(0);
		}
		return bout.toByteArray();
	}

	/**
	 * 读取卡信息tags 可以读取的卡信息Tag有：5A、57、5F34
	 *
	 * @author: Administrator
	 * @return tag列表
	 * @throws Exception 异常
	 */
	public static byte[] getReadCardInfoTag() throws Exception {
		ByteArrayOutputStream ous = new ByteArrayOutputStream();
		ous.write(combine(0x5A));
		ous.write(combine(0x57));
		ous.write(combine(0x5F, 0x34));
		ous.write(combine(0x5F, 0x24));
		return ous.toByteArray();
	}

	/**
	 * PBOC 55域用法一 tags 用于消费、预授权、余额查询
	 *
	 * @author: Administrator
	 * @return 55域tag串
	 */
	public static byte[] getF55UseModeOneTags() {
		try {
			ByteArrayOutputStream ous = new ByteArrayOutputStream();
			ous.write(combine(0x9F, 0x26));
			ous.write(combine(0x9F, 0x27));
			ous.write(combine(0x9F, 0x10));
			ous.write(combine(0x9F, 0x37));
			ous.write(combine(0x9F, 0x36));
			ous.write(combine(0x95));
			ous.write(combine(0x9A));
			ous.write(combine(0x9C));
			ous.write(combine(0x9F, 0x02));
			ous.write(combine(0x5F, 0x2A));
			ous.write(combine(0x82));
			ous.write(combine(0x9F, 0x1A));
			ous.write(combine(0x9F, 0x03));
			ous.write(combine(0x9F, 0x33));
			ous.write(combine(0x9F, 0x34));
			ous.write(combine(0x9F, 0x35));
			ous.write(combine(0x9F, 0x1E));
			ous.write(combine(0x84));
			ous.write(combine(0x9F, 0x09));
			ous.write(combine(0x9F, 0x41));
			ous.write(combine(0x9F, 0x63));
			ous.write(combine(0xDF, 0x32));
			ous.write(combine(0xDF, 0x33));
			ous.write(combine(0xDF, 0x34));
			return ous.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * PBOC 55域用法二 tags 用于消费、预授权的冲正
	 *
	 * @author: Administrator
	 * @return 55域tag串
	 */
	public static byte[] getF55UseModeTwoTags() {
		try {
			ByteArrayOutputStream ous = new ByteArrayOutputStream();
			ous.write(combine(0x95));
			ous.write(combine(0x9F, 0x1E));
			ous.write(combine(0x9F, 0x10));
			ous.write(combine(0x9F, 0x36));
			ous.write(combine(0xDF, 0x31));
			ous.write(combine(0xDF, 0x32));
			ous.write(combine(0xDF, 0x33));
			ous.write(combine(0xDF, 0x34));
			return ous.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * PBOC 55域用法三 tags 用于圈存类交易上送：现金充值、指定账户圈存、非指定账户圈存上送报文F55
	 *
	 * @author: Administrator
	 * @return 55域tag串
	 */
	public static byte[] getF55UseModeThreeTags() {
		try {
			ByteArrayOutputStream ous = new ByteArrayOutputStream();
			ous.write(combine(0x9F, 0x26));
			ous.write(combine(0x9F, 0x27));
			ous.write(combine(0x9F, 0x10));
			ous.write(combine(0x9F, 0x37));
			ous.write(combine(0x9F, 0x36));
			ous.write(combine(0x95));
			ous.write(combine(0x9A));
			ous.write(combine(0x9C));
			ous.write(combine(0x9F, 0x02));
			ous.write(combine(0x5F, 0x2A));
			ous.write(combine(0x82));
			ous.write(combine(0x9F, 0x1A));
			ous.write(combine(0x9F, 0x03));
			ous.write(combine(0x9F, 0x33));
			ous.write(combine(0x9F, 0x34));
			ous.write(combine(0x9F, 0x35));
			ous.write(combine(0x9F, 0x1E));
			ous.write(combine(0x84));
			ous.write(combine(0x9F, 0x09));
			ous.write(combine(0x9F, 0x41));
			ous.write(combine(0x9F, 0x63));
			return ous.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * PBOC 55域用法四 tags 用于 IC卡脚本处理通知上送，同时可以根据这些tag判断脚本处理结果
	 *
	 * @author: Administrator
	 * @return 55域tag串
	 */
	public static byte[] getF55UseModeFourTags() {
		try {
			ByteArrayOutputStream ous = new ByteArrayOutputStream();
			ous.write(combine(0x9F, 0x33));
			ous.write(combine(0x95));
			ous.write(combine(0x9F, 0x37));
			ous.write(combine(0x9F, 0x1E));
			ous.write(combine(0x9F, 0x10));
			ous.write(combine(0x9F, 0x26));
			ous.write(combine(0x9F, 0x36));
			ous.write(combine(0x82));
			ous.write(combine(0xDF, 0x31));
			ous.write(combine(0x9F, 0x1A));
			ous.write(combine(0x9A));
			return ous.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * PBOC 55域用法五 tags 用于圈存冲正上送
	 *
	 * @author: Administrator
	 * @return 55域tag串
	 */
	public static byte[] getF55UseModeFiveTags() {
		try {
			ByteArrayOutputStream ous = new ByteArrayOutputStream();
			ous.write(combine(0x95));
			ous.write(combine(0x9F, 0x1E));
			ous.write(combine(0x9F, 0x10));
			ous.write(combine(0x9F, 0x36));
			ous.write(combine(0xDF, 0x31));
			return ous.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 现金充值撤销上送报文F55
	 *
	 * @author :Administrator
	 * @return 55域tag串
	 */
	public static byte[] getF55UseModeSixTags() {
		try {
			ByteArrayOutputStream ous = new ByteArrayOutputStream();
			ous.write(combine(0x9F, 0x1A));
			ous.write(combine(0x9F, 0x03));
			ous.write(combine(0x9F, 0x33));
			ous.write(combine(0x9F, 0x34));
			ous.write(combine(0x9F, 0x35));
			ous.write(combine(0x9F, 0x1E));
			ous.write(combine(0x84));
			ous.write(combine(0x9F, 0x09));
			ous.write(combine(0x9F, 0x41));
			ous.write(combine(0x9F, 0x63));
			ous.write(combine(0x91));
			ous.write(combine(0x71));
			ous.write(combine(0x72));
			ous.write(combine(0x9F, 0x26));
			ous.write(combine(0x9F, 0x27));
			ous.write(combine(0x9F, 0x10));
			ous.write(combine(0x9F, 0x37));
			ous.write(combine(0x9F, 0x36));
			ous.write(combine(0x95));
			ous.write(combine(0x9A));
			ous.write(combine(0x9C));
			ous.write(combine(0x9F, 0x02));
			ous.write(combine(0x5F, 0x2A));
			ous.write(combine(0x82));
			return ous.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 获得55域所有tag列表
	 *
	 * @return 55域tag串
	 */
	public static byte[] getF55Taglist() {
		try {
			ByteArrayOutputStream ous = new ByteArrayOutputStream();
			ous.write(combine(0x9F, 0x26));
			ous.write(combine(0x9F, 0x27));
			ous.write(combine(0x9F, 0x10));
			ous.write(combine(0x9F, 0x37));
			ous.write(combine(0x9F, 0x36));
			ous.write(combine(0x95));
			ous.write(combine(0x9A));
			ous.write(combine(0x9C));
			ous.write(combine(0x9F, 0x02));
			ous.write(combine(0x5F, 0x2A));
			ous.write(combine(0x82));
			ous.write(combine(0x9F, 0x1A));
			ous.write(combine(0x9F, 0x03));
			ous.write(combine(0x9F, 0x33));
			ous.write(combine(0x9F, 0x34));
			ous.write(combine(0x9F, 0x35));
			ous.write(combine(0x9F, 0x1E));
			ous.write(combine(0x84));
			ous.write(combine(0x9F, 0x09));
			ous.write(combine(0x9F, 0x41));
			ous.write(combine(0x9F, 0x63));
			ous.write(combine(0xDF, 0x32));
			ous.write(combine(0xDF, 0x33));
			ous.write(combine(0xDF, 0x34));
			ous.write(combine(0x4F));
			ous.write(combine(0xDF, 0x31));
			ous.write(combine(0x8A));
			ous.write(combine(0x5F, 0x28));
			ous.write(combine(0x9F, 0x74));
			ous.write(combine(0x9B));
			ous.write(combine(0x50));
			ous.write(combine(0x9F, 0x12));
			ous.write(combine(0x9F, 0x4E));
			ous.write(combine(0x9F, 0x7B));
			ous.write(combine(0x9F, 0x77));
			ous.write(combine(0x8F));
			ous.write(combine(0x5A));
			ous.write(combine(0x5F, 0x34));
			ous.write(combine(0x57));
			ous.write(combine(0x91));
			ous.write(combine(0x71));
			ous.write(combine(0x72));
			return ous.toByteArray();
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 余额查询交易的55域tag列表
	 * @return 55域tag串
	 * @throws Exception 异常
	 */
	public static byte[] getQueryBalanceTag() throws Exception {
		ByteArrayOutputStream ous = new ByteArrayOutputStream();
		ous.write(combine(0x9F, 0x26));
		ous.write(combine(0x9F, 0x27));
		ous.write(combine(0x9F, 0x10));
		ous.write(combine(0x9F, 0x37));
		ous.write(combine(0x9F, 0x36));
		ous.write(combine(0x95));
		ous.write(combine(0x9A));
		ous.write(combine(0x9C));
		ous.write(combine(0x9F, 0x02));
		ous.write(combine(0x5F, 0x2A));
		ous.write(combine(0x82));
		ous.write(combine(0x9F, 0x1A));
		ous.write(combine(0x9F, 0x33));
		ous.write(combine(0x9F, 0x34));
		ous.write(combine(0x9F, 0x35));
		ous.write(combine(0x84));
		ous.write(combine(0x9F, 0x09));
		ous.write(combine(0x9F, 0x1E));
		ous.write(combine(0x9F, 0x03));
		return ous.toByteArray();
	}

	/**
	 * 脚本处理结果tag列表
	 * @return 55域tag串
	 * @throws Exception 异常
     */
	public static byte[] getScriptResultTag() throws Exception {
		ByteArrayOutputStream ous = new ByteArrayOutputStream();
		ous.write(combine(0x9F, 0x33));
		ous.write(combine(0x95));
		ous.write(combine(0x9F, 0x37));
		ous.write(combine(0x9F, 0x1E));
		ous.write(combine(0x9F, 0x10));
		ous.write(combine(0x9F, 0x26));
		ous.write(combine(0x9F, 0x36));
		ous.write(combine(0x82));
		ous.write(combine(0xDF, 0x31));
		ous.write(combine(0x9F, 0x1A));
		ous.write(combine(0x9A));
		return ous.toByteArray();
	}

	/**
	 * 冲正交易的55域tag列表
	 * @return 55域tag串
	 * @throws Exception 异常
     */
	public static byte[] getReservalTag() throws Exception {
		ByteArrayOutputStream ous = new ByteArrayOutputStream();
		ous.write(combine(0x9F, 0x26));
		ous.write(combine(0x9F, 0x27));
		ous.write(combine(0x9F, 0x10));
		ous.write(combine(0x9F, 0x37));
		ous.write(combine(0x9F, 0x36));
		ous.write(combine(0x95));
		ous.write(combine(0x9A));
		ous.write(combine(0x9C));
		ous.write(combine(0x9F, 0x02));
		ous.write(combine(0x5F, 0x2A));
		ous.write(combine(0x82));
		ous.write(combine(0x9F, 0x1A));
		ous.write(combine(0x9F, 0x03));
		ous.write(combine(0x9F, 0x33));
		ous.write(combine(0x9F, 0x34));
		ous.write(combine(0x9F, 0x35));
		ous.write(combine(0x9F, 0x1E));
		ous.write(combine(0x84));
		ous.write(combine(0x9F, 0x09));
		ous.write(combine(0x9F, 0x41));
		ous.write(combine(0x9F, 0x63));

		return ous.toByteArray();
	}

}
